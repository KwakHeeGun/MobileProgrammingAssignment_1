package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;


public class signActivity extends AppCompatActivity {
    Button Signup;
    Button Check;
    EditText newId;
    EditText newPw;
    EditText newName;
    EditText newNum;
    EditText newAd;
    RadioGroup radioGroup;
    RadioButton accept,decline;
    int gun = 0;
    int gun2 = 0;

    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signup);
        Signup = findViewById(R.id.btnSu);
        newId = findViewById(R.id.SuId);
        newPw = findViewById(R.id.SuPw);
        Check = findViewById(R.id.btnJb);
        radioGroup = findViewById(R.id.radioGroup);
        accept = findViewById(R.id.btnAg1);
        decline = findViewById(R.id.btnAg2);
        newName = findViewById(R.id.SuName);
        newNum = findViewById(R.id.SuNum);
        newAd = findViewById(R.id.SuAd);

        Check.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                String currentId = newId.getText().toString();
                try{
                    FileInputStream input = openFileInput("ID.txt");
                    BufferedReader buffer = new BufferedReader(new InputStreamReader(input));
                    String gugu = buffer.readLine(); // 파일에서 한줄을 읽어옴
                    gun = 2;
                    while( gugu != null){
                        if(currentId.equals(gugu)){
                            Toast.makeText(getApplicationContext(),"해당 ID가 이미 존재합니다.", Toast.LENGTH_LONG).show();
                            gun = 0;
                            break;
                        }
                        gun = 1;
                        gugu = buffer.readLine();
                    }
                    Toast.makeText(getApplicationContext(),"사용가능한 ID.",Toast.LENGTH_LONG).show();
                    buffer.close();
                }
                catch (Exception e){
                    e.printStackTrace();
                }
            }
        });

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener(){
            public void onCheckedChanged(RadioGroup radioGroup, int i){
                switch (i){
                    case R.id.btnAg1:
                        gun2 = 1;
                        break;
                    case R.id.btnAg2:
                        gun2 = 0;
                        break;
                }
            }
        });

        Signup.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                String id = newId.getText().toString();
                String pw = newPw.getText().toString();
                String name = newName.getText().toString();
                String num = newNum.getText().toString();
                String ad = newAd.getText().toString();

                if(id.equals("") || pw.equals("") || name.equals("") || num.equals("") || ad.equals("") ){
                    Toast.makeText(getApplicationContext(),"입력되지 않은 정보가 있습니다.", Toast.LENGTH_LONG).show();
                }
                else {
                    if (gun2 == 1) {
                        if (gun == 1 || gun == 2) {
                            try {
                                FileOutputStream ouput1 = openFileOutput("ID.txt", Context.MODE_APPEND);
                                FileOutputStream ouput2 = openFileOutput("PW.txt", Context.MODE_APPEND);
                                FileOutputStream ouput3 = openFileOutput("name.txt", Context.MODE_APPEND);
                                FileOutputStream ouput4 = openFileOutput("hp.txt", Context.MODE_APPEND);
                                FileOutputStream ouput5 = openFileOutput("adress.txt", Context.MODE_APPEND);

                                PrintWriter PWr1 = new PrintWriter(ouput1);
                                PrintWriter PWr2 = new PrintWriter(ouput2);
                                PrintWriter PWr3 = new PrintWriter(ouput3);
                                PrintWriter PWr4 = new PrintWriter(ouput4);
                                PrintWriter PWr5 = new PrintWriter(ouput5);

                                PWr1.println(id);
                                PWr2.println(pw);
                                PWr3.println(name);
                                PWr4.println(num);
                                PWr5.println(ad);

                                PWr1.close();
                                PWr2.close();
                                PWr3.close();
                                PWr4.close();
                                PWr5.close();

                                Intent intent = new Intent(signActivity.this, MainActivity.class);
                                startActivity(intent);

                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        } else {
                            Toast.makeText(getApplicationContext(), "ID 중복검사를 해주세요.", Toast.LENGTH_LONG).show();
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "약관에 동의해주세요.", Toast.LENGTH_LONG).show();
                    }
                }
            }
        });


    }


}

package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.content.Context;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
public class MainActivity extends AppCompatActivity {

    Button Login;
    Button Signup;
    EditText Id;
    EditText Password;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        try {
            FileOutputStream output = openFileOutput("ID.txt", Context.MODE_APPEND);

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        final StringBuffer data = new StringBuffer();
        Login = findViewById(R.id.btnL);
        Signup = findViewById(R.id.btnS);
        Id = findViewById(R.id.ID);
        Password = findViewById(R.id.PW);

        Signup.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                Intent intent = new Intent(MainActivity.this, signActivity.class);
                startActivity(intent);
            }
        });

        Login.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                int gun = 0;
                String gun2 = Id.getText().toString();
                String gun3 = Password.getText().toString();
                Intent intent = new Intent(MainActivity.this, calcActivity.class);

                try{
                    FileInputStream input = openFileInput("ID.txt");
                    BufferedReader buffer = new BufferedReader(new InputStreamReader(input));
                    String gugu = buffer.readLine();
                    while(gugu != null){
                        if(gun2.equals(gugu)){ gun +=1;}
                        gugu = buffer.readLine();
                    }
                    buffer.close();
                }
                catch(Exception e){
                    e.printStackTrace();
                }
                try{
                    FileInputStream input = openFileInput("PW.txt");
                    BufferedReader buffer = new BufferedReader(new InputStreamReader(input));
                    String gugu = buffer.readLine();
                    while(gugu != null){
                        if(gun3.equals(gugu)){ gun +=1;}
                        gugu = buffer.readLine();
                    }
                    buffer.close();
                }
                catch(Exception e){
                    e.printStackTrace();
                }
                if(gun == 2){
                    startActivity(intent);
                }
                else{
                    Toast.makeText(getApplicationContext(),"아이디 또는 패스워드가 옳지 않습니다.", Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}
package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class calcActivity extends AppCompatActivity {

    static final int Plus = 1;
    static final int Minus = 2;
    static final int Div = 3;
    static final int Mul = 4;

    Button num0,num1,num2,num3,num4,num5,num6,num7,num8,num9;
    Button add,sub,div,mul,con,clear;
    TextView show;
    double d1,d2,d3;
    String number1, number2;
    int operator = 0;
    int flag = 0;

    public void onClick(View v){
        if(flag == 1){
            show.setText("");
        }
        switch(v.getId()){
            case R.id.btn0 :
                show.setText(show.getText()+"0");
                break;
            case R.id.btn1 :
                show.setText(show.getText()+"1");
                break;
            case R.id.btn2 :
                show.setText(show.getText()+"2");
                break;
            case R.id.btn3 :
                show.setText(show.getText()+"3");
                break;
            case R.id.btn4 :
                show.setText(show.getText()+"4");
                break;
            case R.id.btn5 :
                show.setText(show.getText()+"5");
                break;
            case R.id.btn6 :
                show.setText(show.getText()+"6");
                break;
            case R.id.btn7 :
                show.setText(show.getText()+"7");
                break;
            case R.id.btn8 :
                show.setText(show.getText()+"8");
                break;
            case R.id.btn9 :
                show.setText(show.getText()+"9");
                break;
        }
        flag = 0;
    }
    Button.OnClickListener mListener = new Button.OnClickListener(){
        public void onClick(View v){
            if(show.getText().toString() == null){
                Toast.makeText(calcActivity.this,"수를 입력하세요.",Toast.LENGTH_SHORT).show();
            }
            switch(v.getId()){
                case R.id.add:

                    number1 = show.getText().toString();
                    operator = Plus;
                    flag = 1;
                    break;
                case R.id.sub:
                    number1 = show.getText().toString();
                    operator = Minus;
                    flag = 1;
                    break;
                case R.id.div:
                    number1 = show.getText().toString();
                    operator = Div;
                    flag = 1;
                    break;
                case R.id.mul:
                    number1 = show.getText().toString();
                    operator = Mul;
                    flag = 1;
                    break;
                case R.id.con:
                    number2 = show.getText().toString();
                    d1 = Double.parseDouble(number1);
                    d2 = Double.parseDouble(number2);

                    if(operator == Plus){
                        d3 = d1 + d2;
                        show.setText("" + d3);
                    }
                    else if (operator == Minus) {
                        d3 = d1 - d2;
                        show.setText("" + d3);
                    }
                    else if (operator == Mul) {
                        d3 = d1 * d2;
                        show.setText("" + d3);
                    }
                    else if (operator == Div) {
                        d3 = d1 / d2;
                        show.setText("" + d3);
                    }
                    number1 = show.getText().toString();
                    break;
                case R.id.clear:
                    number1 = "";
                    number2 = "";
                    operator = 0;
                    flag = 0;
                    show.setText("");
                    break;

            }
        }
    };

    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.calc);
        num0=findViewById(R.id.btn0);
        num1=findViewById(R.id.btn1);
        num2=findViewById(R.id.btn2);
        num3=findViewById(R.id.btn3);
        num4=findViewById(R.id.btn4);
        num5=findViewById(R.id.btn5);
        num6=findViewById(R.id.btn6);
        num7=findViewById(R.id.btn7);
        num8=findViewById(R.id.btn8);
        num9=findViewById(R.id.btn9);

        add = findViewById(R.id.add);
        sub = findViewById(R.id.sub);
        div = findViewById(R.id.div);
        mul = findViewById(R.id.mul);
        con = findViewById(R.id.con);
        clear = findViewById(R.id.clear);
        show = findViewById(R.id.show);

        add.setOnClickListener(mListener);
        sub.setOnClickListener(mListener);
        mul.setOnClickListener(mListener);
        div.setOnClickListener(mListener);
        con.setOnClickListener(mListener);
        clear.setOnClickListener(mListener);

    }




}
